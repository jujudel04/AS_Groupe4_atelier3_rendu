package groupe4.Login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAsApplication.class, args);
	}

}
