package com.group4.play;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayApplicationTests {

	@Test
	void contextLoads() {
	}

}
