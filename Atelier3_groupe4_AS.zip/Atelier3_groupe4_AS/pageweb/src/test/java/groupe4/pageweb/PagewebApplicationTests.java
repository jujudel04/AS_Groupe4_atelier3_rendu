package groupe4.pageweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagewebApplicationTests {

	@Test
	void contextLoads() {
	}

}
