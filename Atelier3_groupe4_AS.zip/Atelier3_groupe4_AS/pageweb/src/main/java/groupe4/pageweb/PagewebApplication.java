package groupe4.pageweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagewebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagewebApplication.class, args);
	}

}
